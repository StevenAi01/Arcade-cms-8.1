<?php
$dbGM['host'] = 'localhost';
# add your database name
$dbGM['name'] = 'u319353809_xcmslite';


# add your database user name
$dbGM['user'] = 'u319353809_xcmslite';



# add your database password
$dbGM['pass'] = 'Alex@@202417677';




#dont touch this
$encryption = "vmbtrvw95105595885345**#3738s**A";


#dont forget to add in deatabase gm_settings your domain website or else will not open other page except home page