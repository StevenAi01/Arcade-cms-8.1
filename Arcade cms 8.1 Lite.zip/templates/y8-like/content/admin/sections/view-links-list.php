<li class="__mc-{{VIEW_LINKS_ID}} g-d5 _j4 categories-item">
	<div style="text-align: left;float:left;flex:1;margin-left:20px" class="_category-name">{{VIEW_LINKS_NAME}}</div>
	<div>
		<button class="btn-p btn-small {{VIEW_LINKS_BUTTON_CLASS}} fa {{VIEW_LINKS_ICON}} linksEnableDisable" data-id="{{VIEW_LINKS_ID}}"> {{VIEW_LINKS_ENABLE_DISABLE}}</button>
	</div>
	<hr>
</li>