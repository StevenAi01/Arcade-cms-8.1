<div class="general-box _0e4">
	<div class="header-box">
		<button class="btn-p btn-p4" data-href="{{CONFIG_SITE_URL}}/admin/categories/add"><i class="fa fa-plus icon-middle icon-18"></i> @add_new_category@</button>
	</div>
	<ul class="categories-list scroll-custom">
		{{VIEW_CATEGORIES_LIST}}
	</ul>
</div>