<li class="__mc-{{VIEW_SLIDER_ID}} g-d5 _j4 categories-item">
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-type">{{VIEW_SLIDER_TYPE}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">{{VIEW_SLIDER_CATEGORY_TAGS}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">{{VIEW_SLIDER_ORDERING}}</div>
	<div>
		<button data-href="{{CONFIG_SITE_URL}}/admin/sliders/edit/{{VIEW_SLIDER_ID}}" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
		{{VIEW_SLIDER_BUTTON_DELETE}}
	</div>
</li>