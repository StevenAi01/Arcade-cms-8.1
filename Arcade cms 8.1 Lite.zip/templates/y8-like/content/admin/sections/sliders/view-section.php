<div class="general-box _0e4">
	<div class="header-box">
		<button class="btn-p btn-p4" data-href="{{CONFIG_SITE_URL}}/admin/sliders/add"><i class="fa fa-plus icon-middle icon-18"></i> @add_new_sliders@</button>
	</div>
	<ul class="sliders-list scroll-custom">
		<li class="__mc-header g-d5 _j4 categories-item">
			<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-type">Type</div>
			<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">Category/Tags</div>
			<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">Ordering</div>
			<div>
				Action
			</div>
		</li>
		{{VIEW_SLIDERS_LIST}}
	</ul>
</div>