<div class="gamemonetize-main-headself">
	<i class="fa fa-user"></i>
</div>
<div class="general-box box-m _0e4">
	<div class="header-box">
		<i class="fa fa-search color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="search-useredit-form" method="POST">
			<div class="vByg5">
				<input type="text" name="uid" placeholder="@id_username@">
			</div>
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-search icon-middle"></i>
				@search@
			</button>
		</form>
	</div>
</div>