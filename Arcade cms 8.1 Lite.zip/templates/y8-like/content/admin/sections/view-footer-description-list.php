<li class="__mc-{{VIEW_FOOTER_DESCRIPTION_ID}} g-d5 _j4 categories-item">
<div class="gameicon" style="width:40px;height:40px;border-radius: 50%;background-image: url({{VIEW_FOOTER_DESCRIPTION_IMAGE}});background-size: cover;background-position-x: 50%;background-position-y: 50%;"></div>
	<div style="text-align: left;float:left;flex:1;margin-left:20px" class="_category-name">{{VIEW_FOOTER_DESCRIPTION_NAME}}</div>
	<div>
		<button data-href="{{CONFIG_SITE_URL}}/admin/footerdescription/edit/{{VIEW_FOOTER_DESCRIPTION_ID}}" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
	</div>
</li>