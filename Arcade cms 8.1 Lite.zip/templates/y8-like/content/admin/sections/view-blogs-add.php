<div class="general-box _0e4">
	<div class="header-box">
		<i class="fa fa-plus color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="addblog-form" enctype="multipart/form-data">
			<div class="vByg5">
				<input type="text" name="title" placeholder="@blogs_title@">
			</div>
			<button type="submit"  id="addblog-btn" class="btn-p btn-p1">
				<i class="fa fa-plus icon-middle"></i>
				@add@
			</button>
		</form>
	</div>
</div>