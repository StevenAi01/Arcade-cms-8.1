<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i> TAGS
</div>
{{TAGS_SECTION_CONTENT}}