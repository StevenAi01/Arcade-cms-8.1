<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i> Manage Sidebar
</div>
{{SIDEBAR_SECTION_CONTENT}}