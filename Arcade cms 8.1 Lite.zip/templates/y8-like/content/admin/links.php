<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i> LINKS
</div>
{{LINKS_SECTION_CONTENT}}