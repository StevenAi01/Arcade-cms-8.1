<li class="post splide__slide item_game slider_item">
    <a href="{{SPLIDE_ITEM_URL}}" class="game-item" aria-label="{{SPLIDE_ITEM_TITLE}}" data-wt-video={{SPLIDE_ITEM_WT_VIDEO}}>
        <img src="{{SPLIDE_ITEM_IMAGE}}" alt="{{SPLIDE_ITEM_TITLE}}" loading="lazy">
        <p class="post-name" data-url="{{SPLIDE_ITEM_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px" style="display: none;">{{SPLIDE_ITEM_TITLE}}</p>
    </a>
</li>