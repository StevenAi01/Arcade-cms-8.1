  <li>
      <a href="{{WIDGET_TOPSTAR_URL}}" class="game-item widget" data-wt-video="{{WIDGET_TOPSTAR_WT_VIDEO}}">
          <img src="{{WIDGET_TOPSTAR_IMAGE}}" alt="{{WIDGET_TOPSTAR_NAME}}" loading="lazy">
          <p class="post-name" data-scale="1.2" data-translate="-43.5px,-38px">{{WIDGET_TOPSTAR_NAME}}</p>
      </a>
  </li>