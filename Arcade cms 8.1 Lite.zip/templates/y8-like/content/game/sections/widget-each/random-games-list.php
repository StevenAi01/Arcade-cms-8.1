<div class="post">
    <a href="{{RANDOM_GAME_URL}}" class="game-item widget" aria-label="{{RANDOM_GAME_NAME}}" data-wt-video="{{RANDOM_GAME_WT_VIDEO}}">
        <img src="{{RANDOM_GAME_IMAGE}}" alt="{{RANDOM_GAME_URL}}" loading="lazy">
        <p class="post-name" data-scale="1.2" data-translate="-23px,-25px">{{RANDOM_GAME_NAME}}</p>
    </a>
</div>