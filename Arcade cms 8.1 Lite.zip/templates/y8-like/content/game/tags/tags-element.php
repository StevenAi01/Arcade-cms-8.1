<!-- <p style="font-size: 1.25em !important;margin-bottom:5px;font-weight:600;">@tags@</p> -->
<ul>
    {{TAGS_LIST}}
</ul>