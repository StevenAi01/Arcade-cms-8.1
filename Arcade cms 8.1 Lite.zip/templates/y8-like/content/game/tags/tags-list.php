<li>
    <a href="{{TAGS_URL}}" style="display: flex; align-items: center;padding: 0px 16px;">
        <img style="width: 20px;margin-right: 8px;object-fit: cover;" src="{{TAGS_IMAGE}}" alt="{{TAGS_NAME}}" loading="lazy">
        {{TAGS_NAME}}
    </a>
</li>