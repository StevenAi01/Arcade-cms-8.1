<div class="page-title">
    <h1>{{PAGE_TITLE}}</h1>
    <p>{{PAGE_DESCRIPTION}}</p>
</div>
<div id="Gameinner" class="bgs" style="max-width: 100%;margin-bottom:40px;">
    <div class="partners fn-clear tags-list-container">

    {{CATEGORIES_LIST}}
    </div>
    
</div>
<div id="Gameinner" class="bgs" style="max-width: 100%;margin-bottom:70px;">
    <div class="bottomtext fn-clear" style="padding:20px;">    
        {{FOOTER_DESCRIPTION}}. {{PAGE_TITLE}}
    </div>
</div>