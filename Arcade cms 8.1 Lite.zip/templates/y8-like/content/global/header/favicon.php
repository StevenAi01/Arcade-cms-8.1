<link rel="shortcut icon" href="{{CONFIG_SITE_URL}}/favicon_y8.ico">
<link rel='apple-touch-icon'/ href="{{CONFIG_SITE_URL}}/favicon_y8.ico">