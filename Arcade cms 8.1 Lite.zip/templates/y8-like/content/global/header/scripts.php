<script type="text/javascript">
    var siteUrl = '{{HEADER_URL}}';
</script>

<script src="https://www.google.com/recaptcha/api.js"
    async defer>
</script>