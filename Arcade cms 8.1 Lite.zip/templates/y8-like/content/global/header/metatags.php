<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="x-dns-prefetch-control" content="on" />
<meta name="description" content="{{CONFIG_SITE_DESCRIPTION}}">
<meta name="keywords" content="{{CONFIG_SITE_KEYWORDS}}">
<meta property="og:image" content="{{CONFIG_SITE_URL}}/static/logo/y8/logo-y8.png">