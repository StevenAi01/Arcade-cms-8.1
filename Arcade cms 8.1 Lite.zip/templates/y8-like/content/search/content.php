<div class="gamemonetize-main main-box span100">
	{{SEARCH_CONTENT}}
</div>