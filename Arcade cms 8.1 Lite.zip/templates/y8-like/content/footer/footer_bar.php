<div id="footer" class=fix style="z-index: 999999999;">
    <div class="foot-inner">
        <div class="link-b fn-left">
            <a href="{{CONFIG_SITE_URL}}/contact">Contact</a> |
            <a href="{{CONFIG_SITE_URL}}/about">About Us</a> |
            <a href="https://www.youtube.com/@BestCrazyGames" target="_blank">YouTube</a>
            <!-- <a href="" target="_blank">{{CONFIG_SITE_NAME}}</a> -->|
           <a  href="https://x.com/gamemonetize" target="_blank">X GameMonetize</a> 
        </div>
        <div class="link-b fn-right">
            <a href="{{CONFIG_SITE_URL}}/terms">Terms</a> |
            <a href="{{CONFIG_SITE_URL}}/privacy">Privacy</a> |
            <span>GameMonetize.com &copy; {{CONFIG_THIS_YEAR}}</span>
        </div>
        <div class="link-b2">
            <a href="{{CONFIG_SITE_URL}}/random">Random Game</a>
        </div>
    </div>
</div>