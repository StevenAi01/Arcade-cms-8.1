<a href="{{TAG_URL}}" style="display: flex; align-items: center;">
    <img style="width: 20px;margin-right: 8px;object-fit: cover;" src="{{TAG_IMAGE}}" alt="{{TAG_NAME}}" loading="lazy">
    {{TAG_NAME}}
</a>