<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="sidebar-item logo-title" style="display: flex !important;margin-right: 5px;margin-bottom:10px;justify-content: center;">
            <!-- <div class="sidebar-item-title"> {{CONFIG_SITE_NAME}} </div> -->
            <div class="sidebar-item-title">
                <a href="/">
                    <img src="../../../static/logo/kizi/logo-35.png" alt="logo" width="35" class="logo-icon">
                </a>
            </div>
        </div>
        {{HEADER_SIDEBAR_ITEMS}}
    </div>
</div>