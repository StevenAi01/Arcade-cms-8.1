<a href="#" class="sidebar-item no-hover">
    <div class="sidebar-item-icon"><i class="material-icons-outlined material-symbols-outlined fa fa-search" style="margin-right: 1rem;"></i></div>
    <div class="sidebar-item-title search">
        <form id="search-data-form" method="POST" autocomplete="off">
            <input type="text" name="search_parameter" placeholder="Search...">
            <button type="submit">GO</button>
        </form>
    </div>
</a>