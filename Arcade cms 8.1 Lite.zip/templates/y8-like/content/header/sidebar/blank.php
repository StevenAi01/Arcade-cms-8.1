<a href="#" class="sidebar-item no-hover no-link" aria-label="sidebar item 1">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link" aria-label="sidebar item 2">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link" aria-label="sidebar item 3">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link" aria-label="sidebar item 4">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>