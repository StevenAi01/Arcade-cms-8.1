<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>


<div class="page-title">
    <h1>ALL CATEGORIES</h1>
    <div id="header-desc">{{HEADER_DESC}}</div>
</div>
<div id="Gameinner" class="bgs">
    <div class="partners fn-clear categories-page-container">
        {{CATEGORIES_LIST}}
    </div>
    <div class="bottomtext fn-clear" style="padding:20px;">    
        {{FOOTER_DESCRIPTION_MODIFIED}}
    </div>
</div>


{{FOOTER_CONTENT}}