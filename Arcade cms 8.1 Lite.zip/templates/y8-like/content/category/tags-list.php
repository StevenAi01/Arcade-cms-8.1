 <a href="{{TAGS_URL}}" class="taglink" style="display: flex; align-items: center;">
    <img style="width: 20px;margin-right: 8px;object-fit: cover;" src="{{TAGS_THUMB}}" alt="{{TAGS_NAME}}" loading="lazy">
    {{TAGS_NAME}}
 </a>