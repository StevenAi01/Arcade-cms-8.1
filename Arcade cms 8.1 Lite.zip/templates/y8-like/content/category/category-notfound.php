<div class="small _a-c">
	<div class="_a-c"><i class="fa fa-tag"></i></div>
	<div>@no_category_found@</div>
</div>