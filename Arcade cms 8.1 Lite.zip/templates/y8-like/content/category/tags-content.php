<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{TAGSID}}";</script>
	{{TAGS_CONTENT}}