<link rel="shortcut icon" href="{{CONFIG_SITE_URL}}/favicon_crazygames.ico">
<link rel='apple-touch-icon'/ href="{{CONFIG_SITE_URL}}/favicon_crazygames.ico">