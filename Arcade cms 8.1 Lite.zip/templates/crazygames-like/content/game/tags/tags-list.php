<a href="{{TAGS_URL}}" class="flex items-center text-base font-bold text-white text-opacity-75 no-underline bg-[#212233] h-10 px-4 rounded-lg hover:bg-violet-900">
    {{TAGS_NAME}}
    <span class="inline-block ml-2 text-opacity-100 text-violet-500">{{TAGS_NUMBER}}</span>
</a>