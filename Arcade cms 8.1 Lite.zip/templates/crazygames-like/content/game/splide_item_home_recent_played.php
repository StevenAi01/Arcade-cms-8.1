<a href="{{SPLIDE_ITEM_URL}}" class="relative w-16 shrink-0 lg:w-20" aria-label="{{SPLIDE_ITEM_TITLE}}" data-wt-video="{{SPLIDE_ITEM_WT_VIDEO}}">
    <img src="{{SPLIDE_ITEM_IMAGE}}" alt="{{SPLIDE_ITEM_TITLE}} image" class="object-cover w-full rounded-lg" loading="lazy">
</a>