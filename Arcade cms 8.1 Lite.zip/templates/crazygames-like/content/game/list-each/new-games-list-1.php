<a href="{{NEW_GAME_URL}}" class="relative overflow-hidden new-games-list" aria-label="{{NEW_GAME_NAME}}" data-url="{{NEW_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px" data-wt-video="{{NEW_GAME_WT_VIDEO}}">
    <img src="{{NEW_GAME_IMAGE}}" alt="{{NEW_GAME_IMAGE_ALT}}" loading="lazy" class="object-cover w-full rounded-2xl">
    {{NEW_GAME_FEATURED}}
    {{NEW_GAMES_ICON}}
</a>