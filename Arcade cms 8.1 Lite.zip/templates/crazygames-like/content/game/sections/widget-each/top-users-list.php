<a href="{{WIDGET_TOPSTAR_URL}}" aria-label="{{WIDGET_TOPSTAR_NAME}}" data-wt-video="{{WIDGET_TOPSTAR_WT_VIDEO}}" class="relative" >
    <img src="{{WIDGET_TOPSTAR_IMAGE}}" width="166" height="166" alt="{{WIDGET_TOPSTAR_NAME}} image" loading="lazy" class="object-cover aspect-square rounded-2xl">
    <p class="px-2 mt-2 text-xs font-bold text-center text-white truncate" data-url="{{WIDGET_TOPSTAR_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px">{{WIDGET_TOPSTAR_NAME}}</p>
</a>