<div class="w-full bg-[#212233] p-5 my-5 text-white footer-description">
    {{FOOTER_DESCRIPTION_CONTENT_VALUE}}
    <dl>    
        {{FOOTER_DESCRIPTION}}
    </dl>
</div>