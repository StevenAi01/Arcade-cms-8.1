<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>

<div class="w-full bg-[#212233] p-5 my-5 text-white">
    <div class="blog-post-title">{{BLOG_TITLE}}</div>
    <div class="blog-post-date">Posted on {{BLOG_DATE_CREATED}}</div>
    <hr style="margin: 10px;">
    <img src="{{BLOG_IMAGE_URL}}" class="blog-post-image" alt="{{BLOG_TITLE image}}">
    <div class="px-0 blog-post-post">{{BLOG_POST}}</div>
    <div class="blog-post-bottom"></div>
</div>

{{FOOTER_CONTENT}}