 <a href="{{BLOG_URL}}" class="text-white blog-list-content">
    <div class="blog-list-image" style="background-image: url({{BLOG_IMAGE_URL}})"></div>
    <div class="blog-list-description">
        <div class="blog-list-title">{{BLOG_TITLE}}</div>
        <div class="blog-list-date">Posted on {{BLOG_DATE_CREATED}}</div>
        <div class="blog-list-post">{{BLOG_POST}}</div>
        <div class="blog-list-more text-violet-400">READ MORE >></div>
    </div>
 </a>