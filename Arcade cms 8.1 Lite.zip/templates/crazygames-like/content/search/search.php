<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>
<div class="ad728list">
{{ADS_TOP}}
</div>

<div class="mb-4 text-xl font-extrabold text-white">
		@search_to@ 
		<strong class="text-violet-500">{{SEARCH_PARAMETER}}</strong>
</div>

<div>
	{{SEARCH_RESULT}}
</div>

{{FOOTER_CONTENT}}
