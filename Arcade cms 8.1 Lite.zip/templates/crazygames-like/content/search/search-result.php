<div class="grid grid-cols-2 gap-4 md:grid-cols-5 lg:grid-cols-7 2xl:grid-cols-8 min-[1920px]:grid-cols-9 min-[2560px]:grid-cols-11">
	{{SEARCH_GAMES_LIST}}
</div>