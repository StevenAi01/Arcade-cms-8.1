<a href="{{TAGS_GAME_URL}}" class="relative overflow-hidden new-games-list" aria-label="{{TAGS_GAME_NAME}}" data-wt-video="{{TAGS_GAME_WT_VIDEO}}">
    <img src="{{TAGS_GAME_IMAGE}}" alt="{{TAGS_GAME_NAME}} image" loading="lazy" class="object-cover w-full rounded-xl">
    {{NEW_GAME_FEATURED}}
    {{NEW_GAMES_ICON}}
</a>