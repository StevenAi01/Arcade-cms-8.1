<a href="{{CATEGORY_URL}}" class="flex items-center text-base font-bold text-white text-opacity-75 no-underline bg-[#212233] h-10 px-4 rounded-lg">
    <img class="mr-2 size-4" src="{{CATEGORY_THUMB}}" alt="{{CATEGORY_NAME}} image" loading="lazy">
    {{CATEGORY_NAME}}
    <span class="inline-block ml-2 text-opacity-100 text-violet-600">{{CATEGORY_NUMBER}} Games</span>
</a>