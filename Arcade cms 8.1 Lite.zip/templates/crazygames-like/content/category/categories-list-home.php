<a href="{{CATEGORY_URL}}" class="bg-[#212233] p-4 rounded-2xl flex flex-col text-white text-base font-bold flex-1 shrink-0 w-full">
    <img src="{{CATEGORY_IMAGE}}" alt="{{CATEGORY_NAME}} image" class="object-cover mb-2 rounded-lg size-9">
    <div class="truncate">{{CATEGORY_NAME}}</div>
</a>