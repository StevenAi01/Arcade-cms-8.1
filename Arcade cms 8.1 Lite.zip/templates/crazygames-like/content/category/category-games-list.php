<a href="{{CATEGORY_GAME_URL}}" class="relative overflow-hidden new-games-list" aria-label="{{CATEGORY_GAME_NAME}}" data-wt-video="{{CATEGORY_GAME_WT_VIDEO}}">
    <img src="{{CATEGORY_GAME_IMAGE}}" alt="{{CATEGORY_GAME_NAME}} image" loading="lazy" class="object-cover w-full rounded-xl">
    {{NEW_GAME_FEATURED}}
    {{NEW_GAMES_ICON}}
</a>