<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>
<div>
	<div class="hide-text">
		<h1>{{PAGE_TITLE}}</h1>
		<p>{{IS_SIDEBAR_ENABLED}}</p>
	</div>
	{{IS_SIDEBAR_ENABLED}}
	{{TOP_INFO}}
	{{NEW_GAMES}}
</div>

{{FOOTER_CONTENT}}