<li>
    <a href="{{CATEGORY_URL}}" class="">
        <img src="{{CATEGORY_IMAGE}}" alt="{{CATEGORY_NAME}} image">
        {{CATEGORY_NAME}}
        <!-- <span>({{CATEGORY_NUMBER}})</span> -->
    </a>
</li>